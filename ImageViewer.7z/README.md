# ImageViewer

View common images from your desktop quickly

*View common images from your desktop quickly*

***Really fast and nice looking Image viewing app***

![ScreenShot1](https://raw.githubusercontent.com/xCONFLiCTiONx/ImageViewer/master/ImageViewer.jpg)

_____________________________________________________________________________________

*INSTALLATION*
--------------
No need to install, just extract where you want it, double click and allow it to set defaults and open any image on your drive from explorer.

This is just for quick viewing of images and is not meant for editing or any major photo stuff. Just a simple photo viewer.

I like Windows Photo App on Windows 10 but it takes too long to load so i wrote my own version that does only what i want. And yes, a few seconds to load an app is too long when all you want is something simple. :)
